function SyntaxHighlighter() {
	var syntaxHighlighter;

	function SyntaxHighlighter(syntaxHighlighter) {
		this.syntaxHighlighter = syntaxHighlighter;
	}


}