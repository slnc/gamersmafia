CKEDITOR.plugins.setLang("pbckcode","fr",
{
	title: 'Ajouter du code'
});